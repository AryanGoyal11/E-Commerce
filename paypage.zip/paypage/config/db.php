<?php
// DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "aryan@5132");
define("DB_NAME", "paypage");
